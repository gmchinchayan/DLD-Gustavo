import pandas as pd
import json
import base64
import sys
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import boto3


        
def lambda_handler(event, context):


    print(event)

    
    df=pd.DataFrame.from_dict(json.loads(event["body"]))
    
    
    analyser = SentimentIntensityAnalyzer()

    df['scores'] = df['clean_message_duplicates'].apply(lambda Description: analyser.polarity_scores(Description))

    data=df['scores'].to_dict()

    messages_preds=[i[1]["compound"] for i in data.items()]

    print(messages_preds)

    lambda_client = boto3.client("lambda")
    response = lambda_client.invoke(
	FunctionName='broadcast',
	InvocationType='Event',
	LogType='None',
	Payload=json.dumps({"body" : json.dumps(sum(messages_preds)/len(messages_preds))}))
  
    return {"statusCode": 200}