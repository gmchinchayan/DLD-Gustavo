import jwt
import json
import base64
import math
import requests
from datetime import datetime

import random

#Extension parameters
EXT_SECRET='8u0LgVBJq0gPfsx86X3LGZjRmnOg2SQp7Oh5hCbfQ8g='
EXT_CLIENT_ID='m6vu4dfjwi1lsam5tqvr5z6e3nm3oe'
EXT_OWNER_ID='721280294'

secret = base64.b64decode(EXT_SECRET)
ownerId = EXT_OWNER_ID
clientId = EXT_CLIENT_ID
myChannelId = '721280294' #test channel


bearerPrefix = 'Bearer '
serverTokenDurationSec = 20 #JWT validity parameter in seconds

#building the JWT to send data to the extension
def makeServerToken(channelId):
    
    payload = json.dumps({
    "exp": math.floor((datetime.now()-datetime(1970,1,1)).total_seconds()) + serverTokenDurationSec,
    "channel_id": channelId,
    "user_id": ownerId, # extension owner ID for the call to Twitch PubSub
    "role": 'external',
    "pubsub_perms": {
      "send": ['*'],
    },
  })

    #print(f'token:{payload}')
    #app.logger.info('payload:'+payload)
    return jwt.encode(json.loads(payload), secret, algorithm="HS256")


#Building the HTTP request data
def makeResponceBroadcast(channelId,message):

    #headers to target our extension   
    headers = { "Client-ID": clientId,
                "Content-Type": 'application/json',
                "Authorization": bearerPrefix + makeServerToken(channelId)}  

    #Body to send to data to the extension
    body = {"content_type": 'application/json',
            "message": json.dumps({"sentiment":message,"pred":[random.uniform(-1,1) for i in range(3)]}),
            "targets": ['broadcast']} 


    return headers,body


def lambda_handler(event, context):
      
    #log lambda call for debug
    print(f'event:{event}')
    
    #extracting the data an logging it
    message=json.loads(event["body"])
    #message=event["headers"]["referer"].split('=')[1].replace('+','')
    #message= base64.b64decode(event["body"]).decode('UTF-8')
    print(message)

    hd,bd=makeResponceBroadcast(myChannelId,message)
    
    #sending the request to the extention
    r=requests.post(url=f'https://api.twitch.tv/extensions/message/{myChannelId}',headers=hd,json=bd)

    #logging response from the extension
    print(f'url:{r.request.url}')
    print(f'body:{r.request.body}')
    print(f'headers:{r.request.headers}')
    print(f'response:{r}')
    
    return {'statusCode': 200}