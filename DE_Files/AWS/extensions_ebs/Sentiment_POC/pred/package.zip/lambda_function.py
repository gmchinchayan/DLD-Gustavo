import pandas as pd
import json
import base64
import sys
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import boto3


        
def lambda_handler(event, context):


    print(event)

    
    df=pd.DataFrame.from_dict(json.loads(event["body"]))
    
    
    analyser = SentimentIntensityAnalyzer()

    new_emotes = {
    'omegalul': 2,
    'lilw': 0,
    'monkaw': -3.0,
    'waytoodank': 0,
    'ez': 2.0,
    'clap' : 3.0,
    'lul' : 2.0,
    'booba' : 1.0,
    'pepega' : -3.0,
    'feelsgoodman' : 3.0,
    'wutfac' : -3.0,
    'sadge' : -4.0,
    'kreygasm' : 3.0,
    'kappa' : 0,
    'peeposad' : -4.0,
    'pogu' : 4.0,
    'truening' : 0,
    'lulw' : 2.0,
    'feelsbadman' : -3.0,
    'pogchamp' : 3.0,
    'poggers' : 3.0,
    'heyguys' : 2.0,
    'pepehands': -2.0,
    'rip' : -2.0,
    'seemsgood' : 3.0,
    'notlikethis' : -2.0,
    'clap' : 2.0,
    'pog' : 2.0,
    'smorc' : 0,
    'dansgam' : -4.0,
    'ez' : -1.0,
    'peeposad' : -2.0,    
}

    analyser.lexicon.update(new_emotes)

    df['scores'] = df['clean_message_duplicates'].apply(lambda Description: analyser.polarity_scores(Description))

    data=df['scores'].to_dict()

    messages_preds=[i[1]["compound"] for i in data.items()]

    print(messages_preds)

    """
    SQS_client = boto3.client('sqs')

    q = SQS_client.get_queue_url(QueueName='history.fifo').get('QueueUrl')

    response = SQS_client.send_message(QueueUrl=q, MessageBody=json.dumps({"body" : json.dumps(sum(messages_preds)/len(messages_preds))}))   
    
    """

    Channel=df["Channel"][0]

    lambda_client = boto3.client("lambda")
    response = lambda_client.invoke(
	FunctionName='buffer',
	InvocationType='Event',
	LogType='None',
	Payload=json.dumps({"body" : json.dumps(sum(messages_preds)/len(messages_preds)),"Channel":Channel}))
    
	
    return {"statusCode": 200}